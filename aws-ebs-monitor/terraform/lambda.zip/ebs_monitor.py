import boto3
import os
from datetime import datetime

def get_unattached_volumes(ec2_client):
    """Get unattached EBS volumes and their total size"""
    volumes = ec2_client.describe_volumes(
        Filters=[{'Name': 'status', 'Values': ['available']}]
    )['Volumes']
    
    total_size = sum(v['Size'] for v in volumes)
    return len(volumes), total_size

def get_unencrypted_volumes(ec2_client):
    """Get number of unencrypted EBS volumes"""
    volumes = ec2_client.describe_volumes(
        Filters=[{'Name': 'encrypted', 'Values': ['false']}]
    )['Volumes']
    return len(volumes)

def get_unencrypted_snapshots(ec2_client):
    """Get number of unencrypted snapshots"""
    snapshots = ec2_client.describe_snapshots(
        OwnerIds=['self'],
        Filters=[{'Name': 'encrypted', 'Values': ['false']}]
    )['Snapshots']
    return len(snapshots)

def put_metric(cloudwatch_client, metric_name, value, namespace):
    """Put a metric to CloudWatch"""
    cloudwatch_client.put_metric_data(
        Namespace=namespace,
        MetricData=[
            {
                'MetricName': metric_name,
                'Value': value,
                'Unit': 'Count',
                'Timestamp': datetime.utcnow()
            }
        ]
    )

def lambda_handler(event, context):
    """Main Lambda handler function"""
    # Initialize AWS clients
    ec2_client = boto3.client('ec2')
    cloudwatch_client = boto3.client('cloudwatch')
    
    # Get namespace from environment variable or use default
    namespace = os.environ.get('CLOUDWATCH_NAMESPACE', 'EBSMonitoring')
    
    try:
        # Collect metrics
        unattached_count, total_size = get_unattached_volumes(ec2_client)
        unencrypted_volumes = get_unencrypted_volumes(ec2_client)
        unencrypted_snapshots = get_unencrypted_snapshots(ec2_client)
        
        # Put metrics to CloudWatch
        put_metric(cloudwatch_client, 'UnattachedVolumesCount', unattached_count, namespace)
        put_metric(cloudwatch_client, 'UnattachedVolumesTotalSize', total_size, namespace)
        put_metric(cloudwatch_client, 'UnencryptedVolumesCount', unencrypted_volumes, namespace)
        put_metric(cloudwatch_client, 'UnencryptedSnapshotsCount', unencrypted_snapshots, namespace)
        
        return {
            'statusCode': 200,
            'body': {
                'message': 'Metrics successfully published to CloudWatch',
                'metrics': {
                    'unattached_volumes': unattached_count,
                    'unattached_volumes_size': total_size,
                    'unencrypted_volumes': unencrypted_volumes,
                    'unencrypted_snapshots': unencrypted_snapshots
                }
            }
        }
    except Exception as e:
        print(f"Error collecting metrics: {str(e)}")
        raise 